<!DOCTYPE html>
<html lang="en">

<head>
    <title>issues Management System</title>
    <style>
        <?php include "css/index.css"; ?>
    </style>
</head>

<body>

    <div class="navbar">
        <a href="index.php">
            <img src="assets/apt.png" class="logo">
        </a>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="user/main/register.php">Register</a></li>
            <li><a href="user/main/login.php">Login</a></li>
            <li><a href="facilities.php">Facilities</a></li>
            <li><a href="help.php">Help</a></li>
        </ul>
    </div>

    <div class="content">
        <h1>Aptech Support Portal</h1>
        <p>Welcome to Aptech's Issues Management Portal! We're here to assist you with any challenges you encounter, ensuring a smooth and productive learning experience.</p>
        <div>
            <a href="user/main/login.php"><button type="button">Login </button></a>
        </div>
    </div>

</body>

</html>